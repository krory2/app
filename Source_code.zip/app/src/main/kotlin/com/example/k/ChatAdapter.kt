package com.example.k

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.TypefaceSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.k.databinding.ItemMessageBotBinding
import com.example.k.databinding.ItemMessageImageBinding
import com.example.k.databinding.ItemMessageUserBinding
import kotlinx.coroutines.*
import java.io.File
import java.io.FileOutputStream

class ChatAdapter(
    private val onSaveImage: ((Bitmap) -> Unit)? = null,
    private val onShareImage: ((String) -> Unit)? = null,
    private val onDeleteMessage: ((ChatMessage) -> Unit)? = null,
    private val onEditImage: ((Bitmap, Int) -> Unit)? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_USER = 1
        private const val VIEW_TYPE_BOT = 2
        private const val VIEW_TYPE_IMAGE = 3
        private const val VIEW_TYPE_USER_IMAGE = 4
    }

    private val messages = mutableListOf<ChatMessage>()

    fun submitList(newMessages: List<ChatMessage>) {
        messages.clear()
        messages.addAll(newMessages)
        notifyDataSetChanged()
    }

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    fun updateLastMessage(content: String) {
        if (messages.isNotEmpty()) {
            val lastIndex = messages.size - 1
            messages[lastIndex] = messages[lastIndex].copy(content = content)
            notifyItemChanged(lastIndex)
        }
    }

    fun updateMessageImage(position: Int, imageUrl: String) {
        if (position < messages.size) {
            messages[position] = messages[position].copy(imageUrl = imageUrl)
            notifyItemChanged(position)
        }
    }

    override fun getItemViewType(position: Int): Int {
        val message = messages[position]
        return when {
            message.isUser && message.imageBitmap != null -> VIEW_TYPE_USER_IMAGE
            message.isUser -> VIEW_TYPE_USER
            message.imageUrl != null || message.imageBitmap != null -> VIEW_TYPE_IMAGE
            else -> VIEW_TYPE_BOT
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_USER -> {
                val binding = ItemMessageUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                UserMessageViewHolder(binding)
            }
            VIEW_TYPE_BOT -> {
                val binding = ItemMessageBotBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                BotMessageViewHolder(binding)
            }
            VIEW_TYPE_IMAGE, VIEW_TYPE_USER_IMAGE -> {
                val binding = ItemMessageImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                ImageMessageViewHolder(binding)
            }
            else -> throw IllegalArgumentException("Unknown view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        when (holder) {
            is UserMessageViewHolder -> holder.bind(message)
            is BotMessageViewHolder -> holder.bind(message)
            is ImageMessageViewHolder -> holder.bind(message, position)
        }
    }

    override fun getItemCount(): Int = messages.size

    inner class UserMessageViewHolder(private val binding: ItemMessageUserBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(message: ChatMessage) {
            binding.messageText.text = formatMessage(message.content)
        }
    }

    inner class BotMessageViewHolder(private val binding: ItemMessageBotBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(message: ChatMessage) {
            val formattedText = formatMessage(message.content)
            binding.messageText.text = formattedText
            binding.messageText.movementMethod = LinkMovementMethod.getInstance()
            
            if (message.content.contains("```")) {
                binding.copyBtn.visibility = View.VISIBLE
                binding.copyBtn.setOnClickListener { copyCodeToClipboard(message.content) }
            } else {
                binding.copyBtn.visibility = View.GONE
            }
        }
        
        private fun copyCodeToClipboard(content: String) {
            val codeRegex = "```(?:\\w+)?\\n([\\s\\S]*?)```".toRegex()
            val matchResult = codeRegex.find(content)
            val code = matchResult?.groupValues?.get(1)?.trim() ?: content
            
            val clipboard = binding.root.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("code", code)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(binding.root.context, "✅ تم نسخ الكود", Toast.LENGTH_SHORT).show()
        }
    }

    inner class ImageMessageViewHolder(private val binding: ItemMessageImageBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(message: ChatMessage, position: Int) {
            binding.imagePrompt.text = if (message.content.isNotEmpty()) message.content else "🖼️ صورة"
            
            if (message.imageBitmap != null) {
                binding.imageProgress.visibility = View.GONE
                binding.generatedImage.setImageBitmap(message.imageBitmap)
            } else if (message.imageUrl != null) {
                binding.imageProgress.visibility = View.VISIBLE
                Glide.with(binding.root.context).load(message.imageUrl).into(binding.generatedImage)
                binding.imageProgress.visibility = View.GONE
            }
            
            // ✨ إظهار/إخفاء الأزرار حسب نوع الرسالة ✨
            if (message.isUser) {
                // للمستخدم: تعديل وحذف فقط
                binding.saveImageBtn.visibility = View.GONE
                binding.shareImageBtn.visibility = View.GONE
                binding.editImageBtn.visibility = View.VISIBLE
                binding.deleteImageBtn.visibility = View.VISIBLE
            } else {
                // للمساعد: جميع الأزرار
                binding.saveImageBtn.visibility = View.VISIBLE
                binding.shareImageBtn.visibility = View.VISIBLE
                binding.editImageBtn.visibility = View.VISIBLE
                binding.deleteImageBtn.visibility = View.VISIBLE
            }
            
            binding.saveImageBtn.setOnClickListener {
                message.imageBitmap?.let { onSaveImage?.invoke(it) }
            }
            
            binding.shareImageBtn.setOnClickListener {
                message.imageUrl?.let { onShareImage?.invoke(it) }
            }
            
            binding.editImageBtn.setOnClickListener {
                message.imageBitmap?.let { bitmap ->
                    onEditImage?.invoke(bitmap, position)
                }
            }
            
            binding.deleteImageBtn.setOnClickListener {
                onDeleteMessage?.invoke(message)
            }
        }
    }

    private fun formatMessage(content: String): SpannableString {
        val spannable = SpannableString(content)
        
        val codeBlockPattern = "```(\\w+)?\\n([\\s\\S]*?)```".toRegex()
        codeBlockPattern.findAll(content).forEach { match ->
            val code = match.groupValues[2].trim()
            val start = match.range.first
            val codeStart = content.indexOf(code, start)
            if (codeStart >= 0) {
                spannable.setSpan(BackgroundColorSpan(android.graphics.Color.parseColor("#1E1E1E")), codeStart, codeStart + code.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                spannable.setSpan(ForegroundColorSpan(android.graphics.Color.parseColor("#E6E6E6")), codeStart, codeStart + code.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                spannable.setSpan(TypefaceSpan("monospace"), codeStart, codeStart + code.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        
        val inlineCodePattern = "`([^`]+)`".toRegex()
        inlineCodePattern.findAll(content).forEach { match ->
            val code = match.groupValues[1]
            val start = match.range.first
            spannable.setSpan(BackgroundColorSpan(android.graphics.Color.parseColor("#2D2D2D")), start, start + match.value.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannable.setSpan(ForegroundColorSpan(android.graphics.Color.parseColor("#F48771")), start, start + match.value.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            spannable.setSpan(TypefaceSpan("monospace"), start, start + match.value.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        
        return spannable
    }
}

data class ChatMessage(
    val content: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUrl: String? = null,
    val imageBitmap: Bitmap? = null
)