package com.example.k

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.k.databinding.ActivityMainBinding
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    
    private var _binding: ActivityMainBinding? = null
    private val binding: ActivityMainBinding
        get() = checkNotNull(_binding) { "Activity has been destroyed" }
    
    private var downloadDialog: AlertDialog? = null
    private var progressBar: ProgressBar? = null
    private var progressText: TextView? = null
    private var progressPercent: TextView? = null
    private var downloadJob: Job? = null
    
    private val GITHUB_RAW_URL = "https://raw.githubusercontent.com/krory2/app/main/Data"
    private val VERSION_FILE = "version.json"
    private val UPDATE_APK_NAME = "app_update.apk"
    
    private lateinit var chatAdapter: ChatAdapter
    private val messages = mutableListOf<ChatMessage>()
    private var isTyping = false
    private val handler = Handler(Looper.getMainLooper())
    private var typingRunnable: Runnable? = null
    
    private val models = mapOf(
        "meta-llama/llama-4-scout-17b-16e-instruct" to "Llama 4 Scout 17B",
        "llama-3.3-70b-versatile" to "Llama 3.3 70B",
        "llama-3.1-8b-instant" to "Llama 3.1 8B",
        "mixtral-8x7b-32768" to "Mixtral 8x7B"
    )
    private var currentModel = "llama-3.3-70b-versatile"
    
    private val API_KEY = "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"
    
    private val STORAGE_KEY = "rawdhi_conversations"
    private val conversations = mutableMapOf<String, Conversation>()
    private var currentChatId: String? = null
    
    private var isImageMode = false
    private var generatingDialog: AlertDialog? = null
    private val SAVE_FOLDER_NAME = "فضيل🛡"
    
    private var uploadedImageBitmap: Bitmap? = null
    private var imagePreviewDialog: AlertDialog? = null
    
    // ✨ متغير لتخزين الصورة المراد تعديلها ✨
    private var editingBitmap: Bitmap? = null
    private var editingMessagePosition: Int = -1
    
    private val editImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                handleEditedImage(uri)
            }
        }
    }
    
    private val uploadImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            result.data?.data?.let { uri ->
                showImagePreview(uri)
            }
        }
    }
    
    private val requestStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            openGalleryForUpload()
        } else {
            Toast.makeText(this, "❌ نحتاج صلاحية الوصول للصور", Toast.LENGTH_SHORT).show()
        }
    }
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private val requestNotificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            createNotificationChannel()
            getFCMToken()
        }
    }
    
    private val requestInstallPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { if (packageManager.canRequestPackageInstalls()) installApkFile() }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        customizeStatusBar()
        setupUI()
        setupRecyclerView()
        setupDrawer()
        setupImageButton()
        requestNotificationPermission()
        checkForFileUpdates()
        loadConversationsFromStorage()
    }
    
    private fun customizeStatusBar() {
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
        }
    }
    
    private fun setupUI() {
        binding.sendBtn.setOnClickListener { 
            if (isImageMode) {
                generateImageWithDescription()
            } else {
                sendMessage()
            }
        }
        binding.menuBtn.setOnClickListener { binding.drawerLayout.openDrawer(binding.navigationView) }
        binding.uploadImageBtn.setOnClickListener { checkStoragePermission() }
    }
    
    private fun checkStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                openGalleryForUpload()
            } else {
                requestStoragePermissionLauncher.launch(android.Manifest.permission.READ_MEDIA_IMAGES)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                openGalleryForUpload()
            } else {
                requestStoragePermissionLauncher.launch(android.Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
    }
    
    private fun showImagePreview(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            uploadedImageBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            
            val dialogView = layoutInflater.inflate(R.layout.dialog_image_preview, null)
            val imagePreview = dialogView.findViewById<ImageView>(R.id.imagePreview)
            val descriptionInput = dialogView.findViewById<EditText>(R.id.descriptionInput)
            val charCount = dialogView.findViewById<TextView>(R.id.charCount)
            val cancelBtn = dialogView.findViewById<Button>(R.id.cancelBtn)
            val generateBtn = dialogView.findViewById<Button>(R.id.generateBtn)
            
            imagePreview.setImageBitmap(uploadedImageBitmap)
            
            descriptionInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    charCount.text = "${s?.length ?: 0} حرف"
                }
                override fun afterTextChanged(s: Editable?) {}
            })
            
            imagePreviewDialog = AlertDialog.Builder(this)
                .setView(dialogView)
                .setCancelable(true)
                .create()
            
            cancelBtn.setOnClickListener {
                imagePreviewDialog?.dismiss()
                uploadedImageBitmap = null
            }
            
            generateBtn.setOnClickListener {
                val description = descriptionInput.text.toString().trim()
                imagePreviewDialog?.dismiss()
                
                if (uploadedImageBitmap != null) {
                    // ✨ الصورة كرسالة من المستخدم ✨
                    val userMessage = ChatMessage(
                        content = description.ifEmpty { "🖼️ صورة" },
                        isUser = true,
                        imageBitmap = uploadedImageBitmap
                    )
                    messages.add(userMessage)
                    chatAdapter.addMessage(userMessage)
                    binding.recyclerView.smoothScrollToPosition(messages.size - 1)
                    
                    uploadedImageBitmap?.let { bitmap ->
                        saveImageToGallery(bitmap, "Rawdhi_upload_${System.currentTimeMillis()}.png")
                    }
                    saveCurrentConversation()
                    
                    uploadedImageBitmap = null
                    Toast.makeText(this, "✅ تم إرسال الصورة", Toast.LENGTH_SHORT).show()
                }
            }
            
            imagePreviewDialog?.show()
            
        } catch (e: Exception) {
            Toast.makeText(this, "❌ فشل تحميل الصورة", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun setupImageButton() {
        binding.imageGenBtn.setOnClickListener {
            isImageMode = !isImageMode
            if (isImageMode) {
                binding.imageGenBtn.setBackgroundResource(R.drawable.bg_image_button_active)
                binding.uploadImageBtn.visibility = View.VISIBLE
                binding.messageInput.hint = "اكتب وصف الصورة التي تريدها..."
                Toast.makeText(this, "🎨 وضع إنشاء الصور مفعل", Toast.LENGTH_SHORT).show()
            } else {
                binding.imageGenBtn.setBackgroundResource(R.drawable.bg_image_button)
                binding.uploadImageBtn.visibility = View.GONE
                binding.messageInput.hint = "اكتب رسالتك..."
                Toast.makeText(this, "💬 وضع المحادثة العادي", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun openGalleryForUpload() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        uploadImageLauncher.launch(intent)
    }
    
    // ✨ فتح محرر الصور ✨
    fun openImageEditor(bitmap: Bitmap, position: Int) {
        editingBitmap = bitmap
        editingMessagePosition = position
        
        // حفظ الصورة مؤقتاً للتحرير
        val file = File(cacheDir, "temp_edit_${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { outputStream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
        }
        
        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.provider",
            file
        )
        
        val editIntent = Intent(Intent.ACTION_EDIT).apply {
            setDataAndType(uri, "image/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        
        if (editIntent.resolveActivity(packageManager) != null) {
            editImageLauncher.launch(editIntent)
        } else {
            // فتح المعرض لاختيار صورة للتعديل
            Toast.makeText(this, "اختر تطبيق تعديل الصور", Toast.LENGTH_SHORT).show()
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.type = "image/*"
            editImageLauncher.launch(intent)
        }
    }
    
    private fun handleEditedImage(uri: Uri) {
        try {
            val inputStream = contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            
            if (editingBitmap != null && editingMessagePosition >= 0) {
                // تحديث الصورة الموجودة
                messages[editingMessagePosition] = messages[editingMessagePosition].copy(imageBitmap = bitmap)
                chatAdapter.updateMessageImage(editingMessagePosition, "")
                chatAdapter.notifyItemChanged(editingMessagePosition)
                Toast.makeText(this, "✅ تم تعديل الصورة", Toast.LENGTH_SHORT).show()
            } else {
                // إضافة صورة جديدة
                val imageMessage = ChatMessage(
                    content = "🖼️ صورة معدلة",
                    isUser = true,
                    imageBitmap = bitmap
                )
                messages.add(imageMessage)
                chatAdapter.addMessage(imageMessage)
                binding.recyclerView.smoothScrollToPosition(messages.size - 1)
                Toast.makeText(this, "✅ تم إضافة الصورة المعدلة", Toast.LENGTH_SHORT).show()
            }
            
            saveImageToGallery(bitmap, "Rawdhi_edited_${System.currentTimeMillis()}.png")
            saveCurrentConversation()
            
            editingBitmap = null
            editingMessagePosition = -1
            
        } catch (e: Exception) {
            Toast.makeText(this, "❌ فشل تحميل الصورة المعدلة", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun generateImageWithDescription() {
        val userPrompt = binding.messageInput.text.toString().trim()
        if (userPrompt.isEmpty()) {
            Toast.makeText(this, "الرجاء كتابة وصف للصورة", Toast.LENGTH_SHORT).show()
            return
        }
        
        binding.messageInput.text?.clear()
        binding.emptyState.visibility = View.GONE
        
        showGeneratingDialog()
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val encodedPrompt = URLEncoder.encode(userPrompt, "UTF-8")
                val imageUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024"
                
                val connection = URL(imageUrl).openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()
                
                val inputStream = connection.inputStream
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()
                
                withContext(Dispatchers.Main) {
                    dismissGeneratingDialog()
                    
                    val imageMessage = ChatMessage(
                        content = userPrompt,
                        isUser = false,
                        imageUrl = imageUrl,
                        imageBitmap = bitmap
                    )
                    messages.add(imageMessage)
                    chatAdapter.addMessage(imageMessage)
                    binding.recyclerView.smoothScrollToPosition(messages.size - 1)
                    
                    val fileName = "Rawdhi_${System.currentTimeMillis()}.png"
                    saveImageToGallery(bitmap, fileName)
                    
                    saveCurrentConversation()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    dismissGeneratingDialog()
                    showError("❌ فشل في إنشاء الصورة: ${e.message}")
                }
            }
        }
    }
    
    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(
            onSaveImage = { bitmap -> saveImageToGallery(bitmap, "Rawdhi_${System.currentTimeMillis()}.png") },
            onShareImage = { url -> shareImage(url) },
            onDeleteMessage = { message -> deleteImageMessage(message) },
            onEditImage = { bitmap, position -> openImageEditor(bitmap, position) }
        )
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).apply {
                stackFromEnd = true
            }
            adapter = chatAdapter
        }
        updateEmptyState()
    }
    
    private fun setupDrawer() {
        binding.navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_new_chat -> {
                    newChat()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.menu_clear_history -> {
                    showClearHistoryDialog()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.model_llama4 -> {
                    currentModel = "meta-llama/llama-4-scout-17b-16e-instruct"
                    updateModelBadge()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.model_llama33 -> {
                    currentModel = "llama-3.3-70b-versatile"
                    updateModelBadge()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.model_llama31 -> {
                    currentModel = "llama-3.1-8b-instant"
                    updateModelBadge()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.model_mixtral -> {
                    currentModel = "mixtral-8x7b-32768"
                    updateModelBadge()
                    binding.drawerLayout.closeDrawers()
                    true
                }
                else -> {
                    val conv = conversations.values.find { it.id.hashCode() == menuItem.itemId }
                    if (conv != null) {
                        loadConversation(conv.id)
                        binding.drawerLayout.closeDrawers()
                        true
                    } else false
                }
            }
        }
        
        val headerView = binding.navigationView.getHeaderView(0)
        headerView.findViewById<ImageButton>(R.id.closeSidebarBtn)?.setOnClickListener {
            binding.drawerLayout.closeDrawers()
        }
    }
    
    private fun showClearHistoryDialog() {
        AlertDialog.Builder(this)
            .setTitle("حذف سجل الدردشة")
            .setMessage("هل أنت متأكد من حذف جميع المحادثات؟")
            .setPositiveButton("حذف") { _, _ -> clearAllHistory() }
            .setNegativeButton("إلغاء", null)
            .show()
    }
    
    private fun clearAllHistory() {
        conversations.clear()
        saveConversationsToStorage()
        updateChatHistoryMenu()
        newChat()
        Toast.makeText(this, "✅ تم حذف سجل الدردشة", Toast.LENGTH_SHORT).show()
    }
    
    private fun updateModelBadge() {
        binding.modelName.text = models[currentModel] ?: currentModel
    }
    
    private fun newChat() {
        currentChatId = null
        messages.clear()
        chatAdapter.submitList(emptyList())
        updateEmptyState()
    }
    
    private fun updateEmptyState() {
        binding.emptyState.visibility = if (messages.isEmpty()) View.VISIBLE else View.GONE
    }
    
    private fun sendMessage() {
        val text = binding.messageInput.text.toString().trim()
        if (text.isEmpty() || isTyping) return
        
        binding.messageInput.text?.clear()
        binding.emptyState.visibility = View.GONE
        
        val userMessage = ChatMessage(text, true)
        messages.add(userMessage)
        chatAdapter.addMessage(userMessage)
        binding.recyclerView.smoothScrollToPosition(messages.size - 1)
        
        showTypingIndicator()
        sendGroqRequest(text)
    }
    
    private fun showGeneratingDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_generating_image, null)
        val progressBar = dialogView.findViewById<ProgressBar>(R.id.generationProgress)
        val percentText = dialogView.findViewById<TextView>(R.id.progressPercent)
        val statusText = dialogView.findViewById<TextView>(R.id.generatingStatus)
        
        val statusMessages = listOf(
            "🎨 جاري فهم الوصف...",
            "🖌️ رسم الخطوط الأولية...",
            "🎭 إضافة التفاصيل...",
            "✨ اللمسات النهائية..."
        )
        
        generatingDialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .setCancelable(false)
            .create()
        
        generatingDialog?.show()
        
        CoroutineScope(Dispatchers.Main).launch {
            for (i in 0..100 step 5) {
                delay(60)
                progressBar.progress = i
                percentText.text = "$i%"
                
                when (i) {
                    25 -> statusText.text = statusMessages[1]
                    50 -> statusText.text = statusMessages[2]
                    75 -> statusText.text = statusMessages[3]
                }
            }
        }
    }
    
    private fun dismissGeneratingDialog() {
        generatingDialog?.dismiss()
        generatingDialog = null
    }
    
    private fun saveImageToGallery(bitmap: Bitmap, fileName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val resolver = contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$SAVE_FOLDER_NAME")
            }
            
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                resolver.openOutputStream(it)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                }
                Toast.makeText(this, "✅ تم حفظ الصورة في مجلد $SAVE_FOLDER_NAME", Toast.LENGTH_LONG).show()
            }
        } else {
            val picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            val folder = File(picturesDir, SAVE_FOLDER_NAME)
            if (!folder.exists()) folder.mkdirs()
            
            val file = File(folder, fileName)
            FileOutputStream(file).use { outputStream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            }
            
            val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            mediaScanIntent.data = Uri.fromFile(file)
            sendBroadcast(mediaScanIntent)
            
            Toast.makeText(this, "✅ تم حفظ الصورة في مجلد $SAVE_FOLDER_NAME", Toast.LENGTH_LONG).show()
        }
    }
    
    private fun shareImage(url: String?) {
        if (url != null) {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "text/plain"
            shareIntent.putExtra(Intent.EXTRA_TEXT, "تم إنشاء هذه الصورة بواسطة روضي🛡\n$url")
            startActivity(Intent.createChooser(shareIntent, "مشاركة الصورة"))
        }
    }
    
    private fun deleteImageMessage(message: ChatMessage) {
        messages.remove(message)
        chatAdapter.submitList(messages.toList())
        saveCurrentConversation()
    }
    
    private fun showTypingIndicator() {
        isTyping = true
        binding.typingIndicator.visibility = View.VISIBLE
        binding.sendBtn.isEnabled = false
        binding.imageGenBtn.isEnabled = false
        binding.uploadImageBtn.isEnabled = false
    }
    
    private fun hideTypingIndicator() {
        isTyping = false
        binding.typingIndicator.visibility = View.GONE
        binding.sendBtn.isEnabled = true
        binding.imageGenBtn.isEnabled = true
        binding.uploadImageBtn.isEnabled = true
    }
    
    private fun sendGroqRequest(userMessage: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val messagesForAPI = messages.map { 
                    mapOf("role" to if (it.isUser) "user" else "assistant", "content" to it.content) 
                }
                val systemMsg = mapOf("role" to "system", "content" to "اسمك 'روضي🛡'. أنت مساعد ذكي ومفيد. أجب بإيجاز وباللغة العربية.")
                
                val fullMessages = listOf(systemMsg) + messagesForAPI
                
                val json = """
                    {
                        "model": "$currentModel",
                        "messages": ${Gson().toJson(fullMessages)},
                        "temperature": 0.7,
                        "max_tokens": 1000
                    }
                """.trimIndent()
                
                val request = Request.Builder()
                    .url("https://api.groq.com/openai/v1/chat/completions")
                    .addHeader("Authorization", "Bearer $API_KEY")
                    .addHeader("Content-Type", "application/json")
                    .post(json.toRequestBody("application/json".toMediaType()))
                    .build()
                
                val response = client.newCall(request).execute()
                val responseBody = response.body?.string() ?: ""
                
                if (response.isSuccessful) {
                    val data = Gson().fromJson(responseBody, Map::class.java)
                    val choices = data["choices"] as? List<*>
                    val choice = choices?.firstOrNull() as? Map<*, *>
                    val message = choice?.get("message") as? Map<*, *>
                    val reply = message?.get("content") as? String ?: "عذراً، لم أتمكن من الرد"
                    
                    withContext(Dispatchers.Main) {
                        hideTypingIndicator()
                        val botMessage = ChatMessage("", false)
                        messages.add(botMessage)
                        chatAdapter.addMessage(botMessage)
                        typeWriterEffect(reply, messages.size - 1)
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        hideTypingIndicator()
                        showError("خطأ في الاتصال: ${response.code}")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    hideTypingIndicator()
                    showError("خطأ: ${e.message}")
                }
            }
        }
    }
    
    private fun typeWriterEffect(text: String, position: Int) {
        var index = 0
        val speed = 12L
        
        typingRunnable = object : Runnable {
            override fun run() {
                if (index <= text.length) {
                    val partialText = text.substring(0, index)
                    messages[position] = messages[position].copy(content = partialText)
                    chatAdapter.updateLastMessage(partialText)
                    binding.recyclerView.smoothScrollToPosition(position)
                    index++
                    handler.postDelayed(this, speed)
                } else {
                    typingRunnable = null
                    saveCurrentConversation()
                }
            }
        }
        handler.post(typingRunnable!!)
    }
    
    private fun showError(message: String) {
        val errorMessage = ChatMessage("❌ $message", false)
        messages.add(errorMessage)
        chatAdapter.addMessage(errorMessage)
        binding.recyclerView.smoothScrollToPosition(messages.size - 1)
    }
    
    private fun saveCurrentConversation() {
        if (messages.isEmpty()) return
        
        val chatId = currentChatId ?: System.currentTimeMillis().toString()
        currentChatId = chatId
        
        val title = messages.firstOrNull()?.content?.take(30) ?: "محادثة جديدة"
        
        val messagesForStorage = messages.map { msg ->
            msg.copy(imageBitmap = null)
        }
        
        conversations[chatId] = Conversation(
            id = chatId,
            title = title,
            messages = messagesForStorage,
            model = currentModel,
            lastUpdated = System.currentTimeMillis()
        )
        
        saveConversationsToStorage()
        updateChatHistoryMenu()
    }
    
    private fun saveConversationsToStorage() {
        val json = Gson().toJson(conversations.values.toList())
        getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .edit()
            .putString(STORAGE_KEY, json)
            .apply()
    }
    
    private fun loadConversationsFromStorage() {
        val json = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .getString(STORAGE_KEY, null) ?: return
        
        try {
            val list = Gson().fromJson(json, Array<Conversation>::class.java)
            conversations.clear()
            list.forEach { conversations[it.id] = it }
            updateChatHistoryMenu()
        } catch (e: Exception) {}
    }
    
    private fun loadConversation(chatId: String) {
        val conversation = conversations[chatId] ?: return
        currentChatId = chatId
        messages.clear()
        messages.addAll(conversation.messages)
        chatAdapter.submitList(messages.toList())
        currentModel = conversation.model
        updateModelBadge()
        updateEmptyState()
    }
    
    private fun updateChatHistoryMenu() {
        val menu = binding.navigationView.menu
        val historyMenu = menu.findItem(R.id.menu_history)
        val subMenu = historyMenu?.subMenu
        subMenu?.clear()
        
        val sorted = conversations.values.sortedByDescending { it.lastUpdated }
        sorted.forEach { conv ->
            subMenu?.add(0, conv.id.hashCode(), 0, conv.title)
                ?.setIcon(R.drawable.ic_history)
        }
    }
    
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestNotificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            } else {
                createNotificationChannel()
                getFCMToken()
            }
        } else {
            createNotificationChannel()
            getFCMToken()
        }
    }
    
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("rawdhi_channel", "إشعارات روضي", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "إشعارات تطبيق روضي"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    
    private fun getFCMToken() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if (task.isSuccessful) { }
        }
    }
    
    private fun checkForFileUpdates() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL("$GITHUB_RAW_URL/$VERSION_FILE")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10000
                connection.readTimeout = 10000
                
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val json = connection.inputStream.bufferedReader().readText()
                    val versionData = Gson().fromJson(json, Map::class.java)
                    
                    val remoteFilesVersion = (versionData["files_version"] as? Double)?.toInt() ?: 0
                    val filesUpdated = versionData["files_updated"] as? Boolean ?: false
                    
                    val sharedPrefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                    val localFilesVersion = sharedPrefs.getInt("files_version", 0)
                    
                    if (filesUpdated && remoteFilesVersion > localFilesVersion) {
                        withContext(Dispatchers.Main) { showDownloadDialog(false) }
                        val success = downloadAllFiles()
                        if (success) {
                            sharedPrefs.edit().putInt("files_version", remoteFilesVersion).apply()
                        }
                    }
                    
                    checkForApkUpdate()
                }
                connection.disconnect()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
    
    private suspend fun checkForApkUpdate() {
        try {
            val url = URL("$GITHUB_RAW_URL/$UPDATE_APK_NAME")
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "HEAD"
            connection.connectTimeout = 5000
            
            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val sharedPrefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                val lastApkCheck = sharedPrefs.getLong("last_apk_check", 0)
                
                if (System.currentTimeMillis() - lastApkCheck > 3600000) {
                    withContext(Dispatchers.Main) { showDownloadDialog(true) }
                    downloadApk()
                    sharedPrefs.edit().putLong("last_apk_check", System.currentTimeMillis()).apply()
                }
            }
            connection.disconnect()
        } catch (e: Exception) {}
    }
    
    private fun showDownloadDialog(isApk: Boolean) {
        runOnUiThread {
            val dialogView = layoutInflater.inflate(R.layout.dialog_download, null)
            progressBar = dialogView.findViewById(R.id.progressBar)
            progressText = dialogView.findViewById(R.id.progressText)
            progressPercent = dialogView.findViewById(R.id.progressPercent)
            
            downloadDialog = AlertDialog.Builder(this)
                .setTitle(if (isApk) "🔄 جاري تحميل التحديث" else "🔄 جاري تحديث الموارد")
                .setView(dialogView)
                .setCancelable(false)
                .create()
            downloadDialog?.show()
        }
    }
    
    private fun updateProgress(current: Long, total: Long, fileName: String) {
        runOnUiThread {
            if (total > 0) {
                val percent = (current * 100 / total).toInt()
                progressBar?.max = 100
                progressBar?.progress = percent
                progressPercent?.text = "$percent%"
                
                val currentMB = current / 1024.0 / 1024.0
                val totalMB = total / 1024.0 / 1024.0
                progressText?.text = "$fileName\n${String.format("%.2f", currentMB)} / ${String.format("%.2f", totalMB)} MB"
            } else {
                progressBar?.isIndeterminate = true
                progressText?.text = "$fileName\nجاري التحميل..."
            }
        }
    }
    
    private suspend fun downloadAllFiles(): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val filesToDownload = listOf("index.html", "style.css", "script.js")
                
                var success = 0
                filesToDownload.forEachIndexed { index, fileName ->
                    updateProgress((index + 1).toLong(), filesToDownload.size.toLong(), fileName)
                    if (downloadFileWithProgress(fileName)) success++
                }
                
                withContext(Dispatchers.Main) {
                    downloadDialog?.dismiss()
                    Toast.makeText(this@MainActivity, "✅ تم تحديث $success/${filesToDownload.size} ملف", Toast.LENGTH_SHORT).show()
                }
                
                success == filesToDownload.size
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    downloadDialog?.dismiss()
                    Toast.makeText(this@MainActivity, "❌ فشل التحميل", Toast.LENGTH_SHORT).show()
                }
                false
            }
        }
    }
    
    private suspend fun downloadApk() {
        withContext(Dispatchers.IO) {
            try {
                val success = downloadFileWithProgress(UPDATE_APK_NAME)
                
                withContext(Dispatchers.Main) {
                    downloadDialog?.dismiss()
                    if (success) {
                        Toast.makeText(this@MainActivity, "✅ تم تحميل التحديث", Toast.LENGTH_SHORT).show()
                        val apkFile = File(filesDir, UPDATE_APK_NAME)
                        if (apkFile.exists()) showInstallDialog(apkFile)
                    } else {
                        Toast.makeText(this@MainActivity, "❌ فشل تحميل التحديث", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    downloadDialog?.dismiss()
                    Toast.makeText(this@MainActivity, "❌ خطأ في التحميل", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    private suspend fun downloadFileWithProgress(fileName: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL("$GITHUB_RAW_URL/$fileName")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 30000
                connection.readTimeout = 30000
                
                if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                    val fileSize = connection.contentLength.toLong()
                    val inputStream = connection.inputStream
                    val file = File(filesDir, fileName)
                    
                    FileOutputStream(file).use { output ->
                        val buffer = ByteArray(8192)
                        var bytesRead: Int
                        var totalBytesRead = 0L
                        
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                            totalBytesRead += bytesRead
                            
                            if (fileSize > 0) {
                                withContext(Dispatchers.Main) {
                                    updateProgress(totalBytesRead, fileSize, fileName)
                                }
                            }
                        }
                    }
                    inputStream.close()
                    true
                } else {
                    false
                }
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
    
    private fun showInstallDialog(apkFile: File) {
        AlertDialog.Builder(this)
            .setTitle("✨ تحديث جديد جاهز")
            .setMessage("تم تحميل الإصدار الجديد بنجاح. هل تريد تثبيته الآن؟")
            .setPositiveButton("تثبيت الآن") { _, _ -> installApk(apkFile) }
            .setNegativeButton("لاحقاً", null)
            .setCancelable(false)
            .show()
    }
    
    private fun installApk(apkFile: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES)
            intent.data = Uri.parse("package:$packageName")
            requestInstallPermissionLauncher.launch(intent)
            return
        }
        installApkFile()
    }
    
    private fun installApkFile() {
        val apkFile = File(filesDir, UPDATE_APK_NAME)
        if (!apkFile.exists()) {
            Toast.makeText(this, "ملف التحديث غير موجود", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val apkUri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                FileProvider.getUriForFile(this, "${packageName}.provider", apkFile)
            } else {
                Uri.fromFile(apkFile)
            }
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "فشل التثبيت: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    
    override fun onBackPressed() {
        if (binding.drawerLayout.isDrawerOpen(binding.navigationView)) {
            binding.drawerLayout.closeDrawers()
        } else {
            super.onBackPressed()
        }
    }
    
    override fun onDestroy() {
        handler.removeCallbacks(typingRunnable ?: return)
        downloadJob?.cancel()
        generatingDialog?.dismiss()
        imagePreviewDialog?.dismiss()
        _binding = null
        super.onDestroy()
    }
}

data class Conversation(
    val id: String,
    val title: String,
    val messages: List<ChatMessage>,
    val model: String,
    val lastUpdated: Long
)